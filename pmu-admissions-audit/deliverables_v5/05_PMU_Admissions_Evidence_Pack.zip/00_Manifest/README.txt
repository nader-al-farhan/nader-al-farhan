PMU Admissions — Evidence Pack (v5.0, 22 Oct 2026)
Prepared by Nader Al Farhan, Administrative Assistant, Student Affairs, Admission Office

00_Manifest — README, Manifest.csv (every file, description, source URL, date, linked IDs, MD5) and Evidence_Manifest.csv (visual evidence: Finding → Evidence → Resource → Source → Decision → Action)
01_Current_Live_Evidence — ORIGINAL captures of 22 Oct 2026 (FNNN_ENNN_Name_20261022.png, unaltered), full-page captures, page text, link status, live re-check
02_Annotated_Live_Evidence — ANNOTATED copies (_ANNOTATED.png): identical to the original plus a red reference frame and a dark label band
03_PDF_Evidence — linked PDF guides, the original page-20 extract (E014) and the full page-20 rendering
04_Historical_Evidence — amendment requests of 26 Oct 2025 with current status; baseline text of 21 Oct 2026 (comparison only)
05_Governing_References — external references and official PMU fee pages
06_AR_EN_Parity — Arabic–English comparison register
07_QA — quality-gate record, independent challenge record, visual evidence QA

Times are Asia/Riyadh. Conflict sources are separate captures and are never merged into one image.
