PMU Admissions — Evidence Pack (v4.0, 22 Oct 2026)
Prepared by Nader Al Farhan, Administrative Assistant, Student Affairs, Admission Office

00_Manifest — this file and Manifest.csv (every file, description, source URL, date, linked IDs, MD5)
01_Current_Live_Evidence — annotated captures (EV-*), original full-page captures (R-*), page text, link status, live re-check
02_PDF_Evidence — linked PDF guides and the page-20 image
03_Historical_Evidence — amendment requests of 26 Oct 2025; baseline capture of 21 Oct 2026
04_Reference_Material — official external references and PMU fee pages
05_QA — quality-gate record and independent challenge record

Annotated copies carry a reviewer highlight; originals are unaltered.
